﻿Jeu créer pour la game Jam Make A Game French 2016

Le but du jeu est d'allé le plus loin possible sans rencontrer de sapin.

Les touches de deplacement sont : 
                                 -deplacement : qd et touche directionnel
                                 -accepter    : touche entrer

